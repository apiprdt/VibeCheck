"""Git hook integrations."""
