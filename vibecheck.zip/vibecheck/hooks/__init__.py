"""Git hook integrations."""
